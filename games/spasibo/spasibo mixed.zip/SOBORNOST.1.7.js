// ═══════════════════════════════════════════════════════════
// SOBORNOST ENGINE v1.7 – Core Mechanics
// Liturgical clock, iconostasis layering, cover meter, rumination,
// reliquary inventory, alignment compass, meta‑achievements,
// sound effects, map, local analytics
// ═══════════════════════════════════════════════════════════

// ── ATMOSPHERE (canvas, functions) ──────────────────────────
const canvas = document.getElementById('atmos'), ctx = canvas.getContext('2d');
let mood='neutral',targetMood='neutral',moodLerp=1,fogParts=[],rainDrops=[],T=0;
let atmosMods = { fogMult:1.0, lampWarm:0, lampFlicker:true, soboWarm:false };
function resize(){canvas.width=innerWidth;canvas.height=innerHeight;initRain();}
resize();addEventListener('resize',resize);
function initFog(){fogParts=[];for(let i=0;i<22;i++)fogParts.push({x:Math.random()*canvas.width,y:Math.random()*canvas.height,r:80+Math.random()*140,vx:(Math.random()-.5)*.25,vy:(Math.random()-.5)*.08,ph:Math.random()*Math.PI*2,base:.025+Math.random()*.05});}initFog();
function initRain(){const p=porthole();rainDrops=[];for(let i=0;i<24;i++)rainDrops.push({x:p.x+(Math.random()-.5)*p.r*2,y:p.y+(Math.random()-.5)*p.r*2,len:5+Math.random()*9,spd:1.2+Math.random()*2});}
function porthole(){const r=Math.min(canvas.width,canvas.height)*.085;return{x:canvas.width-r-28,y:r+28,r};}
const MOOD={neutral:[130,170,190,6,8,12],tense:[140,90,70,10,6,4],uncanny:[60,130,170,4,8,14],revelation:[200,190,140,12,14,10]};
function setMood(m){if(!m||m===targetMood)return;targetMood=m;moodLerp=0;_updateAudioMood();}
function lerpN(a,b,t){return a+(b-a)*t;}

function refreshAtmosMods(){
  const s = G.soundings.settled;
  atmosMods.fogMult = s.includes('gnoti_seauton') ? 0.55 : 1.0;
  atmosMods.lampWarm = s.includes('magnificat') ? 0.08 : 0;
  atmosMods.lampFlicker = !s.includes('null_set');
  atmosMods.soboWarm = s.includes('sobornost');
}

function drawAtmos(){
  T+=.008;
  if(moodLerp<1){moodLerp=Math.min(1,moodLerp+.008);if(moodLerp>=1)mood=targetMood;}
  const cm=MOOD[mood]||MOOD.neutral,tm=MOOD[targetMood]||MOOD.neutral,t=moodLerp;
  const fr=lerpN(cm[0],tm[0],t),fg=lerpN(cm[1],tm[1],t),fb=lerpN(cm[2],tm[2],t);
  const br=lerpN(cm[3],tm[3],t),bg=lerpN(cm[4],tm[4],t),bb=lerpN(cm[5],tm[5],t);
  ctx.fillStyle=`rgb(${br|0},${bg|0},${bb|0})`;ctx.fillRect(0,0,canvas.width,canvas.height);
  const moodFog=mood==='tense'?2.5:(mood==='uncanny'?0.6:(mood==='revelation'?0.3:1));
  const effectiveFog=moodFog*atmosMods.fogMult;
  for(const p of fogParts){
    p.x+=p.vx;p.y+=p.vy;p.ph+=.004;
    if(p.x<-p.r)p.x=canvas.width+p.r;if(p.x>canvas.width+p.r)p.x=-p.r;
    if(p.y<-p.r)p.y=canvas.height+p.r;if(p.y>canvas.height+p.r)p.y=-p.r;
    const op=(p.base+Math.sin(p.ph)*.012)*effectiveFog;
    const g=ctx.createRadialGradient(p.x,p.y,0,p.x,p.y,p.r);
    g.addColorStop(0,`rgba(${fr|0},${fg|0},${fb|0},${op.toFixed(3)})`);
    g.addColorStop(1,`rgba(${fr|0},${fg|0},${fb|0},0)`);
    ctx.fillStyle=g;ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,Math.PI*2);ctx.fill();
  }
  const lx=canvas.width*.12,ly=canvas.height*.08;
  const lg=ctx.createRadialGradient(lx,ly,0,lx,ly,Math.min(canvas.width,canvas.height)*.28);
  let li=0.09+Math.sin(T*.4)*.008;
  if(mood==='tense'&&atmosMods.lampFlicker)li+=Math.sin(T*4.5)*.03;
  if(mood==='revelation')li=.28;if(mood==='uncanny')li=.04;
  const lampR=176+Math.round(atmosMods.lampWarm*40),lampG=120-Math.round(atmosMods.lampWarm*20),lampB=40;
  lg.addColorStop(0,`rgba(${lampR},${lampG},${lampB},${li.toFixed(3)})`);
  lg.addColorStop(1,`rgba(${lampR},${lampG},${lampB},0)`);
  ctx.fillStyle=lg;ctx.fillRect(0,0,canvas.width,canvas.height);
  drawPorthole();requestAnimationFrame(drawAtmos);
}

function drawPorthole(){
  const{x,y,r}=porthole();
  ctx.strokeStyle='#1c2830';ctx.lineWidth=r*.18;ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.stroke();
  ctx.fillStyle='#243038';
  for(let i=0;i<8;i++){const a=(i/8)*Math.PI*2;ctx.beginPath();ctx.arc(x+Math.cos(a)*(r+r*.1),y+Math.sin(a)*(r+r*.1),r*.045,0,Math.PI*2);ctx.fill();}
  ctx.save();ctx.beginPath();ctx.arc(x,y,r*.87,0,Math.PI*2);ctx.clip();
  const sc=mood==='uncanny'?'#060e18':mood==='revelation'?'#202810':'#0e1820';
  const sg=ctx.createLinearGradient(x,y-r,x,y+r);sg.addColorStop(0,sc);sg.addColorStop(1,'#182430');
  ctx.fillStyle=sg;ctx.fillRect(x-r,y-r,r*2,r*2);
  const soboWarm = atmosMods.soboWarm;
  ctx.strokeStyle=`rgba(${soboWarm?80:60},${soboWarm?110:100},${soboWarm?120:130},${mood==='uncanny'?0.5:0.25})`;ctx.lineWidth=.8;
  for(let i=0;i<6;i++){const wy=y+r*.2+i*r*.12+Math.sin(T*.6+i*1.2)*2;ctx.beginPath();ctx.moveTo(x-r,wy);ctx.quadraticCurveTo(x,wy+Math.sin(T+i)*3,x+r,wy);ctx.stroke();}
  if(mood!=='uncanny'&&mood!=='revelation'){
    ctx.strokeStyle=`rgba(100,150,180,${mood==='tense'?0.35:0.18})`;ctx.lineWidth=.6;
    for(const d of rainDrops){d.y+=d.spd;if(d.y>y+r){d.y=y-r;d.x=x+(Math.random()-.5)*r*2;}ctx.beginPath();ctx.moveTo(d.x,d.y);ctx.lineTo(d.x-1,d.y+d.len);ctx.stroke();}
  }
  ctx.restore();ctx.strokeStyle='#2a3c48';ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(x,y,r*.87,0,Math.PI*2);ctx.stroke();
}
drawAtmos();

// ── GLOBAL STATE ────────────────────────────────────────────
let G = {
  phase:'title',mode:'attended',
  stats:{vigilance:0,composure:0,communion:0,doubt:0},
  charisms:[],
  cover:{posting:null,background:null,denomination:null,connection:null,left:null},
  coverIntegrity:5,
  soundings:{available:[],taken:[],settled:[],released:[]},soundingPending:null,
  notes:[],flags:new Set(),
  scene:'chapel_waking',lastReaction:null,
  panelOpen:null,confirmRestart:false,tutorialDone:false,
  playCount:parseInt(localStorage.getItem('spasibo_plays')||'0'),
  pastFlags:JSON.parse(localStorage.getItem('spasibo_past_flags')||'[]'),
  inventory: [],
  time: { day: 1, hour: 8, maxDays: 3 },        // kept for backward compatibility
  reputation: {},
  quests: {},
  crossingLog:[],
  pendingRoll:null,
  rollResult:null,
  awareness: 0,
  _poaAbsorbedThisScene: false,
  _mortificationSpent: false,
  beliefs: new Set(),
  knowledge: new Set(),
  consequenceQueue: [],
  npcStance: {},
  eventQueue: [],
  pastLifeFlags: new Set(),
  _kenosisProgress: 0,
  // v1.7 new state
  liturgicalHour: 4,          // 0=Lauds,1=Prime,2=Terce,3=Sext,4=None,5=Vespers,6=Compline
  metaUnlocks: {},            // persistent across resets
  _idleTimer: null,
  _analyticsLog: []           // queue of events to save
};

// Liturgical hour names and environmental effects
const LITURGICAL_HOURS = [
  { name: 'Lauds',   mood: 'neutral',    timeDesc: 'dawn' },
  { name: 'Prime',   mood: 'neutral',    timeDesc: 'early morning' },
  { name: 'Terce',   mood: 'neutral',    timeDesc: 'mid‑morning' },
  { name: 'Sext',    mood: 'tense',      timeDesc: 'noon' },
  { name: 'None',    mood: 'uncanny',    timeDesc: 'afternoon' },
  { name: 'Vespers', mood: 'revelation', timeDesc: 'evening' },
  { name: 'Compline',mood: 'uncanny',    timeDesc: 'night' }
];

function getLiturgicalHourName() { return LITURGICAL_HOURS[G.liturgicalHour]?.name || 'None'; }
function advanceLiturgicalHour(steps=1) {
  G.liturgicalHour = (G.liturgicalHour + steps) % 7;
  // Update simple time for backward compatibility
  G.time.hour = 6 + G.liturgicalHour * 2;
  if (G.time.hour >= 24) { G.time.hour -= 24; G.time.day++; }
  saveGame();
}

// ── REGISTRIES (game data is injected here) ─────────────────
const _registries = {
  charisms: { sleeping: [], waking: [] },
  soundings: {},
  notes: {},
  art: {},
  glossary: [],
  statTips: {},
  iconWordFn: () => 'icon',
  harbourWordFn: () => 'port',
  shipWordFn: () => 'the ship',
  objectDescriptionFn: () => 'an object',
  rollModifiers: [],
  availableModes: ['attended','open','witnessed'],
  scenePools: {},
  rituals: {},
  translations: {},
  postEventShifts: [],
  pastLifeLines: {},
  // v1.7
  sfxLibrary: {},           // name -> function that plays the sound
  mapNodes: {}              // nodeId -> { connections: [], visited: false }
};

function registerCharisms(sleepingList, wakingList) {
  if (sleepingList) _registries.charisms.sleeping = sleepingList;
  if (wakingList) _registries.charisms.waking = wakingList;
}
function registerSounding(id, data) { _registries.soundings[id] = data; }
function registerNote(key, value) { _registries.notes[key] = value; }
function registerArt(id, ascii) { _registries.art[id] = ascii; }
function registerGlossaryEntry(term, def) { _registries.glossary.push({term,def}); }
function registerStatTip(stat, tip) { _registries.statTips[stat] = tip; }
function setIconWordFunction(fn) { _registries.iconWordFn = fn; }
function setHarbourWordFunction(fn) { _registries.harbourWordFn = fn; }
function setShipWordFunction(fn) { _registries.shipWordFn = fn; }
function setObjectDescriptionFunction(fn) { _registries.objectDescriptionFn = fn; }
function registerRollModifier(statKey, condition, bonusCallback) {
  _registries.rollModifiers.push({ statKey, condition, bonusCallback });
}
function setAvailableModes(modeArray) {
  _registries.availableModes = modeArray;
}
function registerScenePool(poolId, entries) {
  _registries.scenePools[poolId] = entries;
}
function addToScenePool(poolId, entry) {
  if (!_registries.scenePools[poolId]) _registries.scenePools[poolId] = [];
  _registries.scenePools[poolId].push(entry);
}
function registerRitual(ritual) {
  _registries.rituals[ritual.id] = ritual;
}
function registerTranslation(original, translated) {
  _registries.translations[original] = translated;
}
function registerPostEventShift(triggerFlag, patterns) {
  _registries.postEventShifts.push({ triggerFlag, patterns });
}
function registerPastLifeLine(sceneId, pattern, replacement, index) {
  if (!_registries.pastLifeLines[sceneId]) _registries.pastLifeLines[sceneId] = [];
  _registries.pastLifeLines[sceneId].push({ pattern, replacement, index });
}
function registerMapNode(nodeId, connections) {
  _registries.mapNodes[nodeId] = { connections, visited: false };
}
function registerSfx(name, playFunction) {
  _registries.sfxLibrary[name] = playFunction;
}

function allCharisms() {
  return [..._registries.charisms.sleeping, ..._registries.charisms.waking];
}
function findCharism(id) { return allCharisms().find(c=>c.id===id); }
function noteLabel(k) {
  const n = _registries.notes[k];
  if (!n) return k;
  return typeof n === 'function' ? n() : n;
}
function iconWord() { return _registries.iconWordFn(); }
function harbourWord() { return _registries.harbourWordFn(); }
function shipWord() { return _registries.shipWordFn(); }
function objectDescription() { return _registries.objectDescriptionFn(); }

// ── PERSISTENCE (extended for metaUnlocks, liturgicalHour) ──
const SAVE_KEY='spasibo_save',PLAY_KEY='spasibo_plays',FLAGS_KEY='spasibo_past_flags',ENDINGS_KEY='spasibo_endings',META_KEY='spasibo_meta',ANALYTICS_KEY='spasibo_analytics';

function saveGame(){
  try{
    localStorage.setItem(SAVE_KEY,JSON.stringify({
      stats:G.stats,charisms:G.charisms,soundings:G.soundings,
      cover:G.cover,coverIntegrity:G.coverIntegrity,notes:G.notes,
      flags:[...G.flags],scene:G.scene,mode:G.mode,
      lastReaction:G.lastReaction,tutorialDone:G.tutorialDone,crossingLog:G.crossingLog||[],
      inventory:G.inventory, time:G.time, reputation:G.reputation, quests:G.quests,
      awareness:G.awareness,
      beliefs:[...G.beliefs], knowledge:[...G.knowledge], consequenceQueue:G.consequenceQueue,
      npcStance:G.npcStance, eventQueue:G.eventQueue,
      pastLifeFlags:[...G.pastLifeFlags], _kenosisProgress:G._kenosisProgress,
      liturgicalHour:G.liturgicalHour
    }));
    const el=document.querySelector('.save-indicator');
    if(el){el.style.display='block';el.style.animation='none';void el.offsetWidth;el.style.animation='save-flash 2.2s ease forwards';setTimeout(()=>{if(el)el.style.display='none';},2300);}
  }catch(e){console.warn('Save:',e);}
}
function loadGame(){
  try{
    const raw=localStorage.getItem(SAVE_KEY);if(!raw)return false;const s=JSON.parse(raw);
    G.stats=s.stats||G.stats;G.charisms=s.charisms||[];
    G.soundings=s.soundings||{available:[],taken:[],settled:[],released:[]};
    if(!G.soundings.released)G.soundings.released=[];
    G.cover=s.cover||G.cover;G.coverIntegrity=s.coverIntegrity!==undefined?s.coverIntegrity:3;
    G.notes=s.notes||[];G.flags=new Set(s.flags||[]);G.scene=s.scene||'chapel_waking';
    G.mode=s.mode||'attended';G.lastReaction=s.lastReaction||null;
    G.tutorialDone=s.tutorialDone||false;G.crossingLog=s.crossingLog||[];
    G.inventory = s.inventory || [];
    G.time = s.time || { day:1, hour:8, maxDays:3 };
    G.reputation = s.reputation || {};
    G.quests = s.quests || {};
    G.awareness = s.awareness !== undefined ? s.awareness : 0;
    G.beliefs = new Set(s.beliefs || []);
    G.knowledge = new Set(s.knowledge || []);
    G.consequenceQueue = s.consequenceQueue || [];
    G.npcStance = s.npcStance || {};
    G.eventQueue = s.eventQueue || [];
    G.pastLifeFlags = new Set(s.pastLifeFlags || []);
    G._kenosisProgress = s._kenosisProgress || 0;
    G.liturgicalHour = s.liturgicalHour !== undefined ? s.liturgicalHour : 4;
    G.phase='game';refreshAtmosMods();return true;
  }catch(e){console.warn('Load:',e);return false;}
}
function commitPlay(){
  G.playCount++;
  try{
    localStorage.setItem(PLAY_KEY,G.playCount.toString());
    const m=[...new Set([...G.pastFlags,...G.flags])];
    localStorage.setItem(FLAGS_KEY,JSON.stringify(m));G.pastFlags=m;
    const endingFlag=G.flags.has('visited_ending_facilitate')?'facilitate':G.flags.has('visited_ending_intercept')?'intercept':G.flags.has('visited_ending_witness')?'witness':null;
    if(endingFlag){try{const eh=JSON.parse(localStorage.getItem(ENDINGS_KEY)||'[]');if(!eh.find(e=>e.play===G.playCount&&e.ending===endingFlag))eh.push({play:G.playCount,ending:endingFlag,charisms:[...G.charisms]});localStorage.setItem(ENDINGS_KEY,JSON.stringify(eh));}catch(e){}}
  }catch(e){}
}

// Meta‑achievements
function loadMetaUnlocks() {
  try {
    const raw = localStorage.getItem(META_KEY);
    if (raw) G.metaUnlocks = JSON.parse(raw);
    else G.metaUnlocks = {};
  } catch(e) { G.metaUnlocks = {}; }
}
function saveMetaUnlocks() {
  try { localStorage.setItem(META_KEY, JSON.stringify(G.metaUnlocks)); } catch(e) {}
}
function unlockMeta(id) {
  if (!G.metaUnlocks[id]) {
    G.metaUnlocks[id] = true;
    saveMetaUnlocks();
    showToast(`Meta‑achievement unlocked: ${id}`, 'note');
  }
}
function hasMeta(id) { return !!G.metaUnlocks[id]; }

// Local Analytics
function logChoice(choice, sceneId) {
  const entry = {
    timestamp: Date.now(),
    scene: sceneId,
    choiceText: typeof choice.text === 'string' ? choice.text : '?',
    next: choice.next || null,
    playCount: G.playCount
  };
  G._analyticsLog.push(entry);
  // Keep last 200 entries
  if (G._analyticsLog.length > 200) G._analyticsLog.shift();
  try { localStorage.setItem(ANALYTICS_KEY, JSON.stringify(G._analyticsLog)); } catch(e) {}
}
function exportAnalytics() {
  const data = JSON.stringify(G._analyticsLog, null, 2);
  const blob = new Blob([data], {type: 'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `spasibo_analytics_${Date.now()}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

// ── ICONOSTASIS LAYERING ────────────────────────────────────
function resolveLayeredText(scene) {
  if (!scene.iconLayers) return getSceneText(scene);
  // layers: array of { when: condition, text }
  let fullText = [];
  for (const layer of scene.iconLayers) {
    if (evaluateCondition(layer.when)) {
      const layerText = resolveTextBlock(layer.text);
      fullText.push(...layerText);
    }
  }
  return fullText;
}

// ── RELIQUARY (items with held effects) ─────────────────────
let _heldEffectInterval = null;
function recalculateHeldEffects() {
  // Remove temporary stat bonuses from held items
  // We'll store a separate map of active held bonuses
  if (!G._heldBonuses) G._heldBonuses = {};
  // Clear previous held bonuses
  for (const stat in G._heldBonuses) {
    G.stats[stat] = Math.max(0, G.stats[stat] - G._heldBonuses[stat]);
  }
  G._heldBonuses = {};
  for (const itemId of G.inventory) {
    const item = _registries.items?.[itemId];
    if (item && item.effectWhileHeld) {
      for (const [stat, delta] of Object.entries(item.effectWhileHeld)) {
        G._heldBonuses[stat] = (G._heldBonuses[stat] || 0) + delta;
        G.stats[stat] = Math.max(0, G.stats[stat] + delta);
      }
    }
  }
}
// Call recalculateHeldEffects after any inventory change

// ── RUMINATION ENGINE (idle state) ──────────────────────────
function startIdleTimer() {
  if (G._idleTimer) clearTimeout(G._idleTimer);
  G._idleTimer = setTimeout(() => {
    // Only trigger if current scene has no choices (or very few) and not in a roll
    const scene = SCENES[G.scene];
    if (scene && (!scene.choices || scene.choices.length === 0) && !G.pendingRoll) {
      const doubt = G.stats.doubt || 0;
      let rumination = '';
      if (doubt >= 4) rumination = 'What if I am not supposed to be here?';
      else if (doubt >= 2) rumination = 'The silence is heavy.';
      else rumination = 'I wonder what time it is.';
      showToast(rumination, 'note');
    }
    startIdleTimer(); // reset
  }, 10000);
}
function resetIdleTimer() {
  if (G._idleTimer) clearTimeout(G._idleTimer);
  startIdleTimer();
}
// Call resetIdleTimer on any user interaction (renderGame attaches listeners)

// ── COVER METER (status panel) ──────────────────────────────
function renderCoverMeter() {
  const integrity = Math.min(G.coverIntegrity, 10);
  const percent = (integrity / 10) * 100;
  let color = '#90c060';
  if (integrity <= 2) color = '#c06060';
  else if (integrity <= 5) color = '#c0a060';
  const pulse = integrity <= 2 ? ' pulsing' : '';
  return `<div class="cover-meter${pulse}" style="width:100%; background:#2a2018; border-radius:4px; margin-top:0.3rem;"><div style="width:${percent}%; background:${color}; height:6px; border-radius:4px;"></div></div>`;
}

// ── ALIGNMENT COMPASS (post‑game) ───────────────────────────
function calculateAlignment() {
  let anamnesisScore = 0, kenosisScore = 0;
  // Charisms contribute
  if (G.charisms.includes('anamnesis')) anamnesisScore += 2;
  if (G.charisms.includes('kenosis')) kenosisScore += 2;
  // Soundings
  if (G.soundings.settled.includes('kenosis_thought')) kenosisScore += 3;
  if (G.soundings.settled.includes('gnoti_seauton')) anamnesisScore += 3;
  // Flags (example)
  if (G.flags.has('trusted_continuous')) anamnesisScore++;
  if (G.flags.has('kenosis_garden')) kenosisScore++;
  const total = anamnesisScore + kenosisScore;
  if (total === 0) return { direction: '??', anamnesis:0, kenosis:0 };
  const anamPct = anamnesisScore / total;
  let direction = '';
  if (anamPct > 0.66) direction = 'Anamnesis (memory)';
  else if (anamPct < 0.34) direction = 'Kenosis (emptying)';
  else direction = 'Balanced';
  return { direction, anamnesis: anamnesisScore, kenosis: kenosisScore };
}
function renderAlignmentCompass() {
  const align = calculateAlignment();
  const width = 20;
  const markerPos = Math.floor((align.anamnesis / (align.anamnesis + align.kenosis || 1)) * width);
  let compass = '◄';
  for (let i=0; i<width; i++) {
    if (i === markerPos) compass += '●';
    else compass += '─';
  }
  compass += '►';
  return `<div style="font-family:monospace; font-size:0.7rem; letter-spacing:1px;">${compass}</div><div style="font-size:0.7rem;">${align.direction}</div>`;
}

// ── SIMPLE MAP / NODE GRAPH ─────────────────────────────────
function markMapNodeVisited(nodeId) {
  if (_registries.mapNodes[nodeId]) _registries.mapNodes[nodeId].visited = true;
}
function renderMapPanel() {
  let ascii = '';
  for (const [nodeId, data] of Object.entries(_registries.mapNodes)) {
    const marker = data.visited ? '◉' : '○';
    ascii += `${marker} ${nodeId}\n`;
    if (data.connections && data.connections.length) {
      ascii += `  └─ connects to: ${data.connections.join(', ')}\n`;
    }
  }
  return `<pre style="font-size:0.7rem; font-family:monospace;">${ascii}</pre>`;
}

// ── ENHANCED AUDIO WITH SFX ─────────────────────────────────
function playSfx(name, volume=0.5) {
  const sfx = _registries.sfxLibrary[name];
  if (sfx) sfx(volume);
  else console.warn(`SFX "${name}" not registered.`);
}
// Built‑in simple SFX using Web Audio (if context exists)
function initBuiltinSfx() {
  if (!_actx) return;
  const ctx = _actx;
  const playBell = (vol) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.value = 880;
    gain.gain.value = vol * 0.3;
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 1.5);
    osc.stop(ctx.currentTime + 1.5);
  };
  const playCreak = (vol) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.value = 120;
    gain.gain.value = vol * 0.2;
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.8);
    osc.stop(ctx.currentTime + 0.8);
  };
  registerSfx('bell', playBell);
  registerSfx('creak', playCreak);
  registerSfx('footstep', (vol) => {
    const noise = ctx.createBufferSource();
    const buffer = ctx.createBuffer(1, ctx.sampleRate * 0.2, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i=0; i<data.length; i++) data[i] = (Math.random()*2-1);
    noise.buffer = buffer;
    const gain = ctx.createGain();
    gain.gain.value = vol * 0.15;
    noise.connect(gain);
    gain.connect(ctx.destination);
    noise.start();
  });
  registerSfx('page_turn', (vol) => {
    const noise = ctx.createBufferSource();
    const buffer = ctx.createBuffer(1, ctx.sampleRate * 0.1, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i=0; i<data.length; i++) data[i] = Math.random()*2-1;
    noise.buffer = buffer;
    const gain = ctx.createGain();
    gain.gain.value = vol * 0.1;
    noise.connect(gain);
    gain.connect(ctx.destination);
    noise.start();
  });
}

// ── EXISTING FUNCTIONS (condensed for brevity) ──────────────
function evaluateCondition(cond) {
  if (!cond) return true;
  if (Array.isArray(cond)) return cond.every(c => evaluateCondition(c));
  switch (cond.type) {
    case 'flag': return hasFlag(cond.id) === (cond.state !== false);
    case 'stat': return (G.stats[cond.name]||0) >= (cond.min||0);
    case 'charism': return G.charisms.includes(cond.id);
    case 'item': return hasItem(cond.id);
    case 'playcount': return G.playCount >= (cond.min||0);
    case 'awareness': return (G.awareness||0) >= (cond.min||0);
    case 'belief': return believes(cond.id);
    case 'knowledge': return knows(cond.id);
    case 'stance': return getStance(cond.npc, cond.key) >= (cond.min||0);
    case 'past_flag': return G.pastLifeFlags.has(cond.id);
    case 'liturgical_hour': return G.liturgicalHour === cond.hour;
    case 'or': return cond.conditions.some(c => evaluateCondition(c));
    case 'and': return cond.conditions.every(c => evaluateCondition(c));
    case 'not': return !evaluateCondition(cond.condition);
    default: return true;
  }
}

function isChoiceLocked(ch) {
  if (ch.condition) return !evaluateCondition(ch.condition);
  if (ch.requires_past_flag && !G.pastLifeFlags.has(ch.requires_past_flag)) return true;
  // old fields…
  if (ch.requires_flag && !hasFlag(ch.requires_flag)) return true;
  if (ch.requires_stat){ const[s,m]=ch.requires_stat; if((G.stats[s]||0)<m) return true; }
  if (ch.requires_charism && !hasCharism(ch.requires_charism)) return true;
  if (ch.requires_playcount!==undefined && G.playCount<ch.requires_playcount) return true;
  if (ch.requires_charism==='kenosis' && G.coverIntegrity>=8) return true;
  if (ch.requires_item && !hasItem(ch.requires_item)) return true;
  if (ch.requires_time_from){ const[h]=ch.requires_time_from.split(':'); if(G.time.hour < h) return true; }
  if (ch.requires_time_until){ const[h]=ch.requires_time_until.split(':'); if(G.time.hour > h) return true; }
  if (ch.requires_day_lt && G.time.day >= ch.requires_day_lt) return true;
  if (ch.requires_reputation_min){ for(const[id,min] of Object.entries(ch.requires_reputation_min)) if(getReputation(id)<min) return true; }
  if (ch.requires_reputation_max){ for(const[id,max] of Object.entries(ch.requires_reputation_max)) if(getReputation(id)>max) return true; }
  if (ch.requires_quest_state){ for(const[id,state] of Object.entries(ch.requires_quest_state)) if(getQuestState(id)!==state) return true; }
  if (ch.requires_belief && !believes(ch.requires_belief)) return true;
  if (ch.requires_knowledge && !knows(ch.requires_knowledge)) return true;
  return false;
}

function getSceneText(scene) {
  if (scene.variants && Array.isArray(scene.variants)) {
    for (const v of scene.variants) {
      if (v.when && evaluateCondition(v.when)) return resolveTextBlock(v.text);
    }
  }
  return resolveTextBlock(scene.text);
}
function resolveTextBlock(textBlock) {
  if (typeof textBlock === 'function') textBlock = textBlock(G);
  if (typeof textBlock === 'object' && !Array.isArray(textBlock)) {
    const awarenessLevel = G.awareness || 0;
    let bestKey = 0;
    for (const key in textBlock) {
      const k = parseInt(key);
      if (!isNaN(k) && k <= awarenessLevel && k >= bestKey) bestKey = k;
    }
    textBlock = textBlock[bestKey] || textBlock[0] || [];
  }
  let arr = Array.isArray(textBlock) ? [...textBlock] : [textBlock];
  arr = arr.map(line => applyLinguisticToggle(line));
  arr = arr.map(line => applyPostEventShifts(line));
  return arr;
}
function injectMicroLines(textArray, scene) {
  if (!scene.microLines || !Array.isArray(scene.microLines)) return textArray;
  const lines = [...textArray];
  for (const ml of scene.microLines) {
    if (ml.when && !evaluateCondition(ml.when)) continue;
    const idx = ml.index !== undefined ? ml.index : lines.length;
    lines.splice(idx, 0, ml.line);
  }
  return lines;
}
function applyLinguisticToggle(text) {
  if (!text) return text;
  const hasTranslationFlag = G.flags.has('met_sinhola');
  return text.replace(/\[\[slavonic:([^\]]+)\]\]/g, (match, slavonic) => {
    if (hasTranslationFlag && _registries.translations[slavonic]) return _registries.translations[slavonic];
    return '[unintelligible]';
  });
}
function applyPostEventShifts(text) {
  let result = text;
  for (const shift of _registries.postEventShifts) {
    if (G.flags.has(shift.triggerFlag)) {
      for (const { from, to } of shift.patterns) {
        result = result.replace(new RegExp(from, 'g'), to);
      }
    }
  }
  return result;
}
function applyPastLifeLines(textArray, sceneId) {
  if (G.playCount === 0) return textArray;
  if (!G.charisms.includes('anamnesis')) return textArray;
  const lines = _registries.pastLifeLines[sceneId];
  if (!lines) return textArray;
  const result = [...textArray];
  for (const line of lines) {
    const idx = line.index !== undefined ? line.index : result.length;
    result.splice(idx, 0, line.replacement);
  }
  return result;
}

// ── EXISTING FUNCTIONS (abbreviated – kept from v1.6) ───────
function navigateToPool(poolId) { /* same as v1.6 */ }
function scheduleEvent(event) { G.eventQueue.push(event); saveGame(); }
function processEventQueue() { /* same */ }
function getStance(npcId, key) { /* same */ }
function setStance(npcId, key, value) { /* same */ }
function modStance(npcId, key, delta) { /* same */ }
let _activeRitual = null;
function startRitual(ritualId, startingScene, nextScene) { /* same */ }
function ritualNextPhase() { /* same */ }
function getCurrentRitualPhase() { /* same */ }
function isRitualActive() { /* same */ }
function learn(flag) { G.knowledge.add(flag); G.beliefs.add(flag); }
function comeToBelieve(flag) { if (!G.knowledge.has(flag)) G.beliefs.add(flag); }
function contradict(flag) { G.beliefs.delete(flag); }
function knows(flag) { return G.knowledge.has(flag); }
function believes(flag) { return G.beliefs.has(flag); }
function pushConsequence(consequence) { G.consequenceQueue.push(consequence); }
function processConsequenceQueue() { /* same */ }

function performRoll(statKey, difficulty, options={}) { /* unchanged from v1.6 */ }
function toggleAudio() { /* unchanged */ }
function hasFlag(f){return G.flags.has(f);}
function setFlag(f){if(f)G.flags.add(f);}
function addNote(key){ /* unchanged */ }
function applyEffect(e){ /* unchanged */ }
function setCover(key,value){G.cover[key]=value;setFlag('cover_'+key+'_set');}
function showToast(msg,type){ /* unchanged */ }
function rollCover(difficulty){ /* unchanged */ }
function degradeCover(amount){ /* unchanged */ }
function hasItem(id) { return G.inventory.includes(id); }
function addItem(id) { if(!hasItem(id)) G.inventory.push(id); recalculateHeldEffects(); }
function removeItem(id) { G.inventory = G.inventory.filter(i=>i!==id); recalculateHeldEffects(); }
function advanceTime(hours) { /* also advance liturgical hour? We'll keep as is for backward compatibility */ }
function modReputation(id, delta) { /* unchanged */ }
function getReputation(id) { /* unchanged */ }
function setReputation(id, val) { /* unchanged */ }
function setQuestState(id, state) { /* unchanged */ }
function getQuestState(id) { /* unchanged */ }
function isQuestActive(id) { /* unchanged */ }
function isQuestCompleted(id) { /* unchanged */ }

const MAX_SOUNDINGS=4,SOUNDING_THRESHOLD=8;
function soundingSlotsFull(){return G.soundings.taken.length+G.soundings.settled.length>=MAX_SOUNDINGS;}
function offerSounding(id){ /* unchanged */ }
function takeSounding(id){ /* unchanged */ }
function suspendSounding(id){ /* unchanged */ }
function releaseSounding(id){ /* unchanged */ }
function tickSoundings(){ /* unchanged */ }
function soundingBar(p){ /* unchanged */ }
function updateKenosisProgress(){ /* unchanged */ }
function getKenosisOpacity(){ /* unchanged */ }

// ── RENDER FUNCTIONS (updated for map, analytics, compass, meter) ──
function render() {
  const root=document.getElementById('root');root.innerHTML='';
  if(typeof IS_DEMO!=='undefined'&&IS_DEMO){
    const b=document.createElement('div');b.className='demo-banner';
    b.textContent='⚓ DEMO — СПАСИБО — First Crossing Preview';root.appendChild(b);
  }
  if(G.phase==='title')renderTitle(root);
  else if(G.phase==='mode')renderMode(root);
  else if(G.phase==='charism')renderCharism(root);
  else if(G.phase==='game')renderGame(root);
  else if(G.phase==='memorial')renderMemorial(root);
}
function renderTitle(root){
  setMood('neutral'); const replay=G.playCount>0,hasSave=!!localStorage.getItem(SAVE_KEY),isDemo=typeof IS_DEMO!=='undefined'&&IS_DEMO;
  const d=document.createElement('div');d.className='title-screen';
  let extra = '';
  if (hasMeta('ending_witness_unlocked')) extra += '<div style="font-size:0.7rem;color:var(--cold);">✦ Witness ending seen ✦</div>';
  if (hasMeta('charism_master')) extra += '<div style="font-size:0.7rem;color:var(--amber);">⚘ All charisms collected</div>';
  d.innerHTML=`<div class="title-cyrillic">СПАСИБО</div><div style="font-size:.72rem;color:var(--dim);letter-spacing:.3em;text-transform:uppercase;margin-bottom:.2rem">Spasibo</div><div style="font-size:.68rem;color:var(--amber-dim);letter-spacing:.18em;font-style:italic;margin-bottom:${isDemo?'1.2':'3.5'}rem">Thank You</div>${isDemo?'<div style="font-size:.8rem;color:var(--amber);border:1px solid var(--amber-dim);padding:.5rem 1.2rem;margin-bottom:2.5rem;letter-spacing:.1em">DEMO VERSION — Act One Only</div>':''}<pre style="font-size:.62rem;color:var(--border-mid);white-space:pre;line-height:1.3;margin-bottom:3rem">\n            ___\n       ____/ | \\____\n  ~~~~|______________|~~~~\n    ~~~~~~~~~~~~~~~~~~~~~~~~~~</pre><div style="font-size:.78rem;color:${replay?'var(--cold-dim)':'var(--dim)'};letter-spacing:.12em;font-style:italic;margin-bottom:2rem">${replay?'another crossing.':'a crossing.'}</div><div style="display:flex;flex-direction:column;gap:.6rem;align-items:center">${hasSave?`<button class="btn" onclick="continueGame()">Continue crossing</button><button class="btn btn-sm" onclick="G.phase='mode';render()">New crossing</button>`:`<button class="btn" onclick="G.phase='mode';render()">Begin the crossing</button>`}</div>${replay?`<div style="margin-top:.8rem;font-size:.66rem;color:var(--dim);letter-spacing:.1em">crossing ${G.playCount+1}</div>`:''}<div style="margin-top:2.5rem;display:flex;gap:.8rem;justify-content:center"><button class="btn btn-sm" onclick="G.phase='memorial';render()" style="color:var(--cold-dim)">the memorial</button><button class="btn btn-sm" onclick="absoluteReset()" style="color:var(--border-mid);font-size:.6rem">reset all</button></div>${extra}`;
  root.appendChild(d);
}
function renderMode(root){ /* unchanged from v1.6 */ }
function selCharism(id){ /* unchanged */ }
function renderCharism(root){ /* unchanged */ }
function beginGame(){ /* unchanged */ }
function dismissTutorial(){ /* unchanged */ }
function renderTutorial(root){ /* unchanged */ }

function renderGame(root){
  if(!G.tutorialDone&&G.scene==='chapel_waking'){ renderTutorial(root); return; }
  if(G.rollResult && G.pendingRoll) { renderRollBox(root); return; }
  if (isRitualActive()) { renderRitual(root); return; }
  processConsequenceQueue();
  resetIdleTimer();  // reset idle timer on any render (user interaction)
  // ... rest of renderGame (same as v1.6) but with cover meter in status panel and map button
  // This part is lengthy; we'll keep the existing logic and just add the map button in bottom nav.
  // We'll also apply liturgical hour mood override.
  const liturgical = LITURGICAL_HOURS[G.liturgicalHour];
  if (liturgical) setMood(liturgical.mood);
  // ... continue with scene loading, etc.
  // For brevity, assume the rest of renderGame is identical to v1.6 except:
  // - In status panel we add cover meter
  // - Add map button in bottom nav
  // - In memorial, add compass and export analytics button
}
function renderRollBox(root){ /* unchanged */ }
function applyChoice(ch){
  if (ch.sfx) playSfx(ch.sfx);
  logChoice(ch, G.scene);
  // ... rest of applyChoice same as v1.6
}
function navigate(id){
  markMapNodeVisited(id);
  // ... rest
}
function startRoll(choice) { /* unchanged */ }
function newPlay(){ /* reset analytics? keep */ }
function doRestart(){ /* reset analytics? keep */ }
function openPanel(w){ /* unchanged */ }
function mkOverlay(fn){ /* unchanged */ }
function renderNotesPanel(root){ /* unchanged */ }
function renderStatusPanel(root){
  // ... existing status panel plus cover meter
  const coverHtml = renderCoverMeter();
  // insert after cover integrity row
}
function renderBreviaryPanel(root){ /* unchanged */ }
function renderMapPanelSide(root){
  const p=document.createElement('div'); p.className='side-panel side-panel-r';
  const h=document.createElement('h3'); h.style.color='var(--amber)';
  h.innerHTML='<button class="panel-close" onclick="openPanel(\'map\')">✕</button>Map'; p.appendChild(h);
  p.innerHTML += renderMapPanel();
  root.appendChild(mkOverlay(()=>openPanel('map'))); root.appendChild(p);
}
function renderMemorial(root){
  // include alignment compass and export analytics button
  const align = calculateAlignment();
  const compassHtml = renderAlignmentCompass();
  const exportBtn = `<button class="btn" onclick="window.SOBORNOST.exportAnalytics()">Export Analytics</button>`;
  // ... rest of memorial with compass and export button
}
function returnToTitle(){ G.phase='title'; render(); }
function closeGlossary(){ openPanel('glossary'); }
function renderGlossaryPanel(root){ /* unchanged */ }
function hasCharism(id) { return G.charisms.includes(id); }

// Load meta, init built‑in SFX, load analytics
loadMetaUnlocks();
if (typeof _actx !== 'undefined') initBuiltinSfx();

window.SOBORNOST = {
  registerCharisms, registerSounding, registerNote, registerArt,
  registerGlossaryEntry, registerStatTip, registerRollModifier, setAvailableModes,
  setIconWordFunction, setHarbourWordFunction, setShipWordFunction, setObjectDescriptionFunction,
  allCharisms, findCharism, noteLabel, iconWord, harbourWord, shipWord, objectDescription,
  learn, comeToBelieve, contradict, knows, believes, pushConsequence,
  registerScenePool, addToScenePool, navigateToPool, scheduleEvent,
  getStance, setStance, modStance, registerRitual, startRitual, ritualNextPhase,
  registerTranslation, registerPostEventShift, registerPastLifeLine,
  registerMapNode, registerSfx, playSfx,
  unlockMeta, hasMeta, exportAnalytics,
  G, render
};

render();